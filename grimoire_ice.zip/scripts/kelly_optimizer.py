# Kelly Criterion logic
