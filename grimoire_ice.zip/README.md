# Grimoire ICE

End-to-end NHL matchup simulator and betting edge predictor.
